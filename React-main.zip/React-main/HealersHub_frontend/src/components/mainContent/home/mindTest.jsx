import React, { useState } from "react";

const moodData = {
  happy: {
    gif: "https://media.giphy.com/media/3oriO0OEd9QIDdllqo/giphy.gif",
    message: "Yay! Keep smiling! 😊",
    resource: "https://www.happify.com/",
  },
  sad: {
    gif: "https://media0.giphy.com/media/hoaFB12CCE824/giphy.gif",
    message: "It's okay to feel sad sometimes. 💙",
    resource: "https://www.betterhelp.com/",
  },
  excited: {
    gif: "https://media3.giphy.com/media/FDbIUZLwbCUS4786z3/giphy.gif",
    message: "Woohoo! Stay awesome! 🎉",
    resource: "https://www.tonyrobbins.com/",
  },
  tired: {
    gif: "https://media0.giphy.com/media/10zHDq77BLwcy4/giphy.gif",
    message: "Take some rest, you deserve it! 😴",
    resource: "https://www.sleepfoundation.org/",
  },
  calm: {
    gif: "https://media1.tenor.com/m/1vP51Z9l2hkAAAAC/cute-pinch.gif",
    message: "Stay relaxed and enjoy the moment! 🌿",
    resource: "https://www.headspace.com/",
  },
  angry: {
    gif: "https://media.giphy.com/media/3o7abKhOpu0NwenH3O/giphy.gif",
    message: "Take a deep breath, it's okay. 🔥",
    resource: "https://www.verywellmind.com/how-to-control-anger-4161147",
  },
  stressed: {
    gif: "https://media1.tenor.com/m/LC2Jp87SCwQAAAAd/little-girl-cute.gif",
    message: "Try to take it one step at a time. 🧘",
    resource: "https://www.stress.org/",
  },
  confused: {
    gif: "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExOHN3Z2lwZnF1cHh5ZmgyYzZ0YWoxdHZ1eTl1d2xpeXh3enhsaG9idSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/ji6zzUZwNIuLS/giphy.gif",
    message: "It's okay to not have all the answers. 🤯",
    resource: "https://www.psychologytoday.com/us",
  },
};

const MoodTest = () => {
  const [selectedMood, setSelectedMood] = useState(null);

  const handleMoodClick = (mood) => {
    setSelectedMood(moodData[mood]);
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center bg-gray-100 p-6 pt-25">
      <div className="text-center bg-white shadow-lg p-6 rounded-lg max-w-4xl w-full">
        <h1 className="text-3xl font-bold text-blue-900 mb-2">How's Your Mood Today? 🫠</h1>
        <p className="text-lg text-blue-900 mb-4">Pick the emoji that best describes your feelings!</p>

        <div className="flex flex-wrap justify-center gap-4 overflow-x-auto py-3">
          {Object.keys(moodData).map((mood) => (
            <button
              key={mood}
              onClick={() => handleMoodClick(mood)}
              className="flex flex-col items-center bg-gradient-to-r from-gray-200 to-gray-300 text-blue-900 border-4 border-yellow-500 rounded-xl p-4 w-32 h-40 shadow-md hover:shadow-lg transform transition-transform hover:-translate-y-2"
            >
              <img src={moodData[mood].gif} alt={mood} className="w-16 h-16 mb-2 rounded-md" />
              <span className="font-semibold text-lg">{mood.charAt(0).toUpperCase() + mood.slice(1)}</span>
            </button>
          ))}
        </div>

        {selectedMood && (
          <div className="mt-6 p-5 bg-gradient-to-r from-gray-200 to-gray-300 text-blue-900 border-4 border-yellow-500 rounded-lg shadow-md text-center">
            <h2 className="text-2xl font-bold mb-2">{selectedMood.message}</h2>
            <img src={selectedMood.gif} alt="Mood GIF" className="w-36 mx-auto my-2 rounded-md" />
            <p className="text-lg">Need help?</p>
            <a href={selectedMood.resource} target="_blank" rel="noopener noreferrer">
              <button className="mt-3 px-6 py-2 bg-orange-500 text-white text-lg rounded-lg hover:bg-orange-600 transition duration-300">
                Resources
              </button>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default MoodTest;