package com.project.HealersHub.service;


import com.project.HealersHub.dtos.MoodSupportResponseDto;

public interface MoodSupportService {
    MoodSupportResponseDto generateMoodSupportResponse(String mood, String stage, String userId);
}
