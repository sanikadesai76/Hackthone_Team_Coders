package com.project.HealersHub.enums;

public enum AppRole {
    ROLE_USER,
    ROLE_ADMIN
}
