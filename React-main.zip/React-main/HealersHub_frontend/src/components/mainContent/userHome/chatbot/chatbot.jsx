import React, { useState, useEffect, useRef } from "react";
import { FaPaperPlane } from "react-icons/fa";
import axios from "axios";
import useAuth from "../../../../hooks/auth";
import Webcam from "react-webcam";

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [userId, setUserId] = useState();
  const [emotion, setEmotion] = useState("");
  const [stage, setStage] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState("");
  const { user } = useAuth();

  const handleLogin = () => {
    setUserId(user.userName);
  };

  useEffect(() => {
    detectEmotion();
    detectStage();
  }, []);

  const detectEmotion = async () => {
    try {
      const response = await axios.get("http://localhost:8080/detect_emotion");
      setEmotion(response.data["Dominant emotion"]);
    } catch (error) {
      console.error("Error detecting emotion:", error);
    }
  };

  const detectStage = async () => {
    try {
      const response = await axios.post("http://localhost:8000/predict", {
        text: "I am in trauma",
      });
      setStage(response.data.stage);
    } catch (error) {
      console.error("Error detecting stage:", error);
    }
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const newMessage = { text: input, sender: "user", userId };
    setMessages([...messages, newMessage]);
    setInput("");

    try {
      const response = await axios.post(
        "http://localhost:8080/api/mood/response",
        {
          mood: emotion,
          stage: stage,
          userId,
        }
      );

      const aiMessage = response.data.content;
      setPopupMessage(aiMessage);
      setShowPopup(true);
    } catch (error) {
      console.error("Error fetching AI response:", error);
    }
  };

  return (
    <div className="flex h-screen w-full pt-28 p-4 bg-gray-100">
      <div className="w-1/2 pr-2">
        <div className="mt-2 text-center font-bold text-lg">
          Detected Emotion: <span className="text-blue-600">{emotion}</span>
        </div>
      </div>

      <div className="w-1/2 pl-2 flex flex-col">
        <div className="bg-blue-600 text-white text-center py-3 font-semibold rounded-t-lg">
          Chatbot
        </div>
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-white rounded-b-lg shadow-lg">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`p-3 max-w-xs rounded-lg ${
                msg.sender === "user"
                  ? "bg-blue-500 text-white self-end ml-auto"
                  : "bg-gray-200 text-gray-800 self-start"
              }`}
            >
              {msg.text}
            </div>
          ))}
        </div>
        <div className="flex items-center p-2 mt-4 bg-white rounded-lg shadow-lg">
          <input
            type="text"
            className="flex-1 p-2 border rounded-lg outline-none"
            placeholder="Type a message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <button
            onClick={sendMessage}
            className="ml-2 p-2 bg-blue-500 text-white rounded-full"
          >
            <FaPaperPlane />
          </button>
        </div>
      </div>

      {showPopup && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
          <div className="bg-white p-5 rounded-lg shadow-lg">
            <h2 className="text-lg font-bold mb-2">Emotional Support</h2>
            <p>{popupMessage}</p>
            <button
              className="mt-3 px-4 py-2 bg-blue-500 text-white rounded"
              onClick={() => setShowPopup(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
