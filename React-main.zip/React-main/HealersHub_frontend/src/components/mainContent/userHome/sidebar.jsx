import './sidebar.css';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <h2 className="sidebar-title">Mental Health Support</h2>
      </div>
      <nav className="sidebar-nav">
        <ul className="sidebar-list">
          <li>
            <a href="#" className="sidebar-link">
              <i className="fas fa-comments"></i>
              <span>Chatbot</span>
            </a>
          </li>
          <li>
            <a href="#" className="sidebar-link">
              <i className="fas fa-heart"></i>
              <span>Healing Section</span>
            </a>
          </li>
          <li>
            <a href="#" className="sidebar-link">
              <i className="fas fa-user"></i>
              <span>Profile</span>
            </a>
          </li>
          <li>
            <a href="#" className="sidebar-link">
              <i className="fas fa-cog"></i>
              <span>Settings</span>
            </a>
          </li>
        </ul>
      </nav>
      <div className="sidebar-footer">
        <a href="#" className="sidebar-link">
          <i className="fas fa-sign-out-alt"></i>
          <span>Logout</span>
        </a>
      </div>
    </aside>
  );
};

export default Sidebar;