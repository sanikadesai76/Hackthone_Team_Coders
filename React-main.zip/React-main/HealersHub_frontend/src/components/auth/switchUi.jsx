import React, { useState } from "react";
import Login from "./login/signIn";
import SignUp from "./signUp/register";

const SwitchUi = () => {
    const [isLogin, setIsLogin] = useState(true);
  
    const toggleForm = () => setIsLogin(!isLogin);
  
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-gray-100">
        <div className="w-full h-full flex">
          {isLogin ? <Login toggle={toggleForm} /> : <SignUp toggle={toggleForm} />}
        </div>
      </div>
    );
  };
  
  export default SwitchUi;