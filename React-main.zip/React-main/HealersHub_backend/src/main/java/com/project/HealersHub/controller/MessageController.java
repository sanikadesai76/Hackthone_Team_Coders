package com.project.HealersHub.controller;


import com.project.HealersHub.entities.Message;
import com.project.HealersHub.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
@CrossOrigin(origins = "http://localhost:3000")
public class MessageController {
    @Autowired
    private MessageRepository messageRepository;

    @GetMapping("/{userId}")
    public List<Message> getMessages(@PathVariable String userId) {
        return messageRepository.findByUserId(userId);
    }

    @PostMapping
    public Message sendMessage(@RequestBody Message message) {
        Message savedMessage = messageRepository.save(message);
        // Simulate bot response
        Message botMessage = new Message();
        botMessage.setText("I'm here to help!");
        botMessage.setSender("bot");
        botMessage.setUserId(message.getUserId());
        return messageRepository.save(botMessage);
    }
}
