import React, { useState } from 'react';
import useAuth from '../../../hooks/auth';

const SignUp = ({ toggle }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const { signup } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    // Client-side validation
    if (username.length < 3 || username.length > 20) {
      setError('Username must be between 3 and 20 characters');
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email) || email.length > 50) {
      setError('Invalid email or exceeds 50 characters');
      return;
    }
    if (password.length < 6 || password.length > 40) {
      setError('Password must be between 6 and 40 characters');
      return;
    }

    try {
      await signup(username, email, password);
      // Navigation to '/login' is handled in useAuth hook
    } catch (err) {
      setError(err.message || 'Signup failed');
    }
  };

  return (
    <div className="flex w-full h-screen">
      {/* Left Side - Signup Form */}
      <div className="w-1/2 flex flex-col justify-center items-center bg-white p-10 shadow-lg">
        <h2 className="text-2xl font-semibold text-gray-800">Create an Account</h2>
        <p className="text-gray-600 mb-4">Join us by filling in the details</p>
        
        {error && <p className="text-red-500 mb-3">{error}</p>}

        <form onSubmit={handleSubmit} className="w-full">
          <input 
            type="text" 
            placeholder="Username" 
            className="w-full p-2 border rounded mb-3"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            minLength={3}
            maxLength={20}
          />
          <input 
            type="email" 
            placeholder="Email" 
            className="w-full p-2 border rounded mb-3"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            maxLength={50}
          />
          <input 
            type="password" 
            placeholder="Password" 
            className="w-full p-2 border rounded mb-3"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
            maxLength={40}
          />
          <input 
            type="password" 
            placeholder="Confirm Password" 
            className="w-full p-2 border rounded mb-3"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            minLength={6}
            maxLength={40}
          />
          <button 
            type="submit"
            className="w-full bg-gradient-to-b from-blue-500 to-indigo-600 text-white p-2 rounded"
          >
            Sign Up
          </button>
        </form>

        <p className="mt-3">
          Already have an account? 
          <span 
            className="text-blue-500 cursor-pointer ml-1" 
            onClick={toggle}
          >
            Log in
          </span>
        </p>
      </div>

      {/* Right Side - Background Image */}
      <div 
        className="w-1/2 h-screen bg-cover bg-center" 
        style={{ backgroundImage: "url('/auth_image.jpeg')" }}
      ></div>
    </div>
  );
};

export default SignUp;