package com.project.HealersHub.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class LetterRequest {
    private String userName;
    private String letterContent;
    private String depth;
}
