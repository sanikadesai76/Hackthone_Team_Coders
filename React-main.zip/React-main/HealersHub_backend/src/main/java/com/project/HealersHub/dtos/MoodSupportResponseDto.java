package com.project.HealersHub.dtos;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MoodSupportResponseDto {
    private String title;
    private String content;
}
