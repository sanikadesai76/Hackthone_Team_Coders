package com.project.HealersHub.service.impl;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.HealersHub.dtos.MoodSupportResponseDto;
import com.project.HealersHub.entities.User;
import com.project.HealersHub.repository.UserRepository;
import com.project.HealersHub.service.MoodSupportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Map;

@Service
public class MoodSupportServiceImpl implements MoodSupportService {

    private final WebClient webClient;

    @Autowired
    private UserRepository userRepository;

    @Value("${gemini.api.url}")
    private String geminiApiUrl;
    @Value("${gemini.api.key}")
    private String geminiApiKey;

    public MoodSupportServiceImpl(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    @Override
    public MoodSupportResponseDto generateMoodSupportResponse(String mood, String stage, String userId) {
        String prompt = buildPrompt(mood, stage, userId);

        Map<String, Object> requestBody = Map.of(
                "contents", new Object[]{
                        Map.of("parts", new Object[]{
                                Map.of("text", prompt)
                        })
                }
        );

        try {
            String response = webClient.post()
                    .uri(geminiApiUrl + geminiApiKey)
                    .header("Content-Type", "application/json")
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            String aiResponse = extractResponseContent(response);

            return MoodSupportResponseDto.builder()
                    .title("Support Messages")
                    .content(aiResponse)
                    .build();
        } catch (WebClientResponseException e) {
            System.err.println("API returned error: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
            return MoodSupportResponseDto.builder()
                    .title("Support Messages")
                    .content("We couldn’t fetch a response right now, but we’re here to support you.")
                    .build();
        }
    }

    private String extractResponseContent(String response) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(response);
            return rootNode.path("candidates")
                    .get(0)
                    .path("content")
                    .path("parts")
                    .get(0)
                    .path("text")
                    .asText();

        }catch (Exception e){
            return "Error processing request: " + e.getMessage();
        }
    }

    private String buildPrompt(String mood, String stage, String userName) {
        return "The user named Dear currently feeling " + mood +
                " and is going through the emotional distress phase: " + stage + ". " +
                "As a compassionate and understanding mental health assistant, respond with empathy and care. " +
                "Start by gently acknowledging how they’re feeling, then invite them to share more about what they’re going through. " +
                "Provide comforting, personalized advice and suggest simple, practical steps they can take right now " +
                "to feel a bit better and more in control. Your tone should be warm, non-judgmental, and sincerely supportive.";
    }

}