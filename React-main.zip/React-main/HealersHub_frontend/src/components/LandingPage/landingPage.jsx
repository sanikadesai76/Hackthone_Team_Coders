import React, { useState, useEffect } from "react";

const Healtogether = () => {
  const phases = ["Breathe In", "Hold", "Breathe Out", "Hold"];
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % phases.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <style>
        {`
          @keyframes breathe {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.5); }
          }
          .animate-breathe {
            animation: breathe 8s infinite ease-in-out;
          }
        `}
      </style>

      <div className="flex flex-col md:flex-row w-screen h-screen">
        {/* Left Section - Content */}
        <div className="w-full md:w-1/2 flex flex-col justify-center items-center text-center p-10">
          <h1 className="text-3xl md:text-4xl font-semibold text-[#13285b] leading-snug">
            Healing begins the moment, <br />
            You choose yourself
          </h1>
          <p className="text-lg text-gray-600 max-w-md mt-4">
            Explore a space of mindfulness, guidance, and growth where your
            journey to inner peace begins
          </p>
          <a href="/mindTest" className="mt-6">
            <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg px-6 py-3 rounded-full text-lg transition hover:shadow-xl hover:brightness-110">
              How's Your Mood ?
            </button>
          </a>
        </div>

        {/* Right Section - Breathing Animation */}
        <div className="w-full md:w-1/2 flex justify-center items-center bg-gradient-to-br from-yellow-400 to-orange-500">
          <div className="w-48 h-48 flex justify-center items-center bg-white text-[#13285b] text-xl font-bold rounded-full shadow-lg animate-breathe">
            {phases[index]}
          </div>
        </div>
      </div>
    </>
  );
};

export default Healtogether;
