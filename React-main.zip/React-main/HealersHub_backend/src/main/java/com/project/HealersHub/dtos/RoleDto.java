package com.project.HealersHub.dtos;

import lombok.Data;

@Data
public class RoleDto {

    private String roleId;
    private String name;
}
