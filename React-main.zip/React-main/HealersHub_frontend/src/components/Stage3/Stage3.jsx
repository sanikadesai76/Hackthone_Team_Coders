import React from 'react';
import { Box, Typography, List, ListItem, ListItemText } from '@mui/material';
import { Phone } from '@mui/icons-material';

const psychiatrists = [
  { name: 'Dr. John Smith', phone: '+1 (555) 123-4567', location: 'New York, NY' },
  { name: 'Dr. Emily Carter', phone: '+1 (555) 987-6543', location: 'Los Angeles, CA' },
  { name: 'Dr. Priya Sharma', phone: '+1 (555) 456-7890', location: 'Chicago, IL' },
];

const SupportPage = () => {
  return (
    <Box sx={{ pt: 12, pb: 8, px: 2, maxWidth: '1200px', mx: 'auto' }}>
      <Typography variant="h4" align="center" sx={{ mb: 4 }}>
        Support Zone (Stage 3)
      </Typography>
      <Typography variant="h6" align="center" sx={{ mb: 4 }}>
        You've made incredible progress! Connect with a professional for the next step.
      </Typography>

      {/* Psychiatrist Contacts */}
      <Box sx={{ maxWidth: 600, mx: 'auto' }}>
        <Typography variant="h5" sx={{ mb: 2 }}>Nearby Psychiatrists</Typography>
        <List>
          {psychiatrists.map((doc, index) => (
            <ListItem key={index} sx={{ borderBottom: '1px solid #ddd' }}>
              <Phone color="primary" sx={{ mr: 2 }} />
              <ListItemText
                primary={doc.name}
                secondary={`${doc.phone} | ${doc.location}`}
              />
            </ListItem>
          ))}
        </List>
      </Box>

      {/* Additional Support */}
      <Box sx={{ textAlign: 'center', mt: 4 }}>
        <Typography variant="body1" color="textSecondary">
          Need immediate help? Call our 24/7 helpline: <strong>+1 (800) 555-HELP</strong>
        </Typography>
      </Box>
    </Box>
  );
};

export default SupportPage;