import { useState } from 'react';
import { Link } from 'react-router-dom';
import './signUp.css';

const Signup = ({ auth }) => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
  
    const handleSubmit = async (e) => {
      e.preventDefault();
      setError('');
      
      if (password !== confirmPassword) {
        setError('Passwords do not match');
        return;
      }
  
      // Basic client-side validation based on DTO constraints
      if (username.length < 3 || username.length > 20) {
        setError('Username must be between 3 and 20 characters');
        return;
      }
      if (!/\S+@\S+\.\S+/.test(email) || email.length > 50) {
        setError('Invalid email or exceeds 50 characters');
        return;
      }
      if (password.length < 6 || password.length > 40) {
        setError('Password must be between 6 and 40 characters');
        return;
      }
  
      try {
        await auth.signup(username, email, password);
      } catch (err) {
        setError('Signup failed: ' + (err.response?.data?.message || 'Unknown error'));
      }
    };
  
    return (
      <main className="signup">
        <div className="signup-container">
          <h2 className="signup-title">Sign Up</h2>
          {error && <p className="signup-error">{error}</p>}
          <form onSubmit={handleSubmit} className="signup-form">
            <div className="signup-field">
              <label>Username</label>
              <input 
                type="text" 
                value={username} 
                onChange={(e) => setUsername(e.target.value)} 
                required 
                minLength={3}
                maxLength={20}
              />
            </div>
            <div className="signup-field">
              <label>Email</label>
              <input 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                required 
                maxLength={50}
              />
            </div>
            <div className="signup-field">
              <label>Password</label>
              <input 
                type="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
                minLength={6}
                maxLength={40}
              />
            </div>
            <div className="signup-field">
              <label>Confirm Password</label>
              <input 
                type="password" 
                value={confirmPassword} 
                onChange={(e) => setConfirmPassword(e.target.value)} 
                required 
                minLength={6}
                maxLength={40}
              />
            </div>
            <button type="submit" className="signup-btn">Sign Up</button>
          </form>
          <p>
            Already have an account? <Link to="/login" className="signup-link">Log in</Link>
          </p>
        </div>
      </main>
    );
  };
  
  export default Signup;