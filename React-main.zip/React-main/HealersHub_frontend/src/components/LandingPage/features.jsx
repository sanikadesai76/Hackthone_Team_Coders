import React from 'react';
import { Box, Typography, Card, CardContent, Chip } from '@mui/material';
import { SmartToy, SportsEsports, Edit } from '@mui/icons-material';

const features = [
  {
    icon: <SmartToy fontSize="large" color="primary" />,
    title: 'AI-Powered Bot',
    description: 'Interact with our smart bot to monitor your mental state and receive real-time insights.',
    chip: 'AI-Driven',
  },
  {
    icon: <SportsEsports fontSize="large" color="primary" />,
    title: 'Games & Tests',
    description: 'Play engaging games and take tests to uncover deeper insights into your personality.',
    chip: 'Interactive',
  },
  {
    icon: <Edit fontSize="large" color="primary" />,
    title: 'Motivational Letters',
    description: 'Receive AI-generated letters tailored to your journey to boost confidence and hope.',
    chip: 'Personalized',
  },
];

const Features = () => {
  return (
    <Box id="features" sx={{ py: 8, bgcolor: '#f5f5f5' }}>
      <Typography variant="h4" align="center" sx={{ fontWeight: 'bold', mb: 6 }}>
        What We Offer
      </Typography>
      <Box sx={{ maxWidth: '1200px', mx: 'auto', px: 2, display: 'flex', flexWrap: 'wrap', gap: 4, justifyContent: 'center' }}>
        {features.map((feature, index) => (
          <Card
            key={index}
            sx={{
              width: { xs: '100%', sm: 300 },
              p: 2,
              textAlign: 'center',
              transition: 'transform 0.3s',
              '&:hover': { transform: 'scale(1.05)' },
            }}
          >
            <CardContent>
              {feature.icon}
              <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                {feature.title}
              </Typography>
              <Typography variant="body2" color="textSecondary">
                {feature.description}
              </Typography>
              <Chip label={feature.chip} color="primary" sx={{ mt: 2 }} />
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default Features;