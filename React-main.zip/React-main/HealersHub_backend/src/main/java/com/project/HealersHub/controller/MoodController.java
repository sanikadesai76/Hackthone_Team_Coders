package com.project.HealersHub.controller;


import com.project.HealersHub.dtos.MoodSupportResponseDto;
import com.project.HealersHub.service.MoodSupportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/mood")
public class MoodController {
    @Autowired
    private MoodSupportService moodSupportService;

    @PostMapping("/response")
    public MoodSupportResponseDto getMoodSupportResponse(@RequestBody Map<String, String> request) {
        String mood = request.get("mood");
        String stage = request.get("stage");  // Accepting the stage from ML Model
        String userId = request.get("userId");

        return moodSupportService.generateMoodSupportResponse(mood, stage, userId);
    }


    private String detectMoodFromImage(String imageBase64) {
        // Simulate mood detection (replace with actual ML model integration)
        return "happy"; // Example: "happy", "sad", "anger", etc.
    }

    private String detectStageFromModel() {
        // Simulate stage detection (replace with actual ML model integration)
        return "Stage 1"; // Example: "Stage 1", "Stage 2", "Stage 3"
    }
}
