import { Routes, Route, useNavigate } from "react-router-dom";
import Navbar from "./components/Navbar/header";
import Hero from "./components/LandingPage/hero";
import Features from "./components/LandingPage/features";
import About from "./components/LandingPage/about";
import Footer from "./components/Footer/footer";
import useAuth from "./hooks/auth";
import HealingPage from "./components/mainContent/Stage2/stage2Home";
import SupportPage from "./components/Stage3/Stage3";
import HomePage from "./components/mainContent/home/home";
import CommunityPage from "./components/community/community";
import { useState } from "react";
import Healtogether from "./components/LandingPage/landingPage";
import AboutUs from "./components/LandingPage/about";
import SwitchUi from "./components/auth/switchUi";
import Chatbot from "./components/mainContent/userHome/chatbot/chatbot";
import MoodTest from "./components/mainContent/home/mindTest";
import Game1 from "./components/mainContent/home/game/game";
import MentalHealthTest from "./components/mainContent/test";

function App() {
  const navigate = useNavigate();
  const auth = useAuth(navigate);

  const [mentalHealth, setMentalHealth] = useState(0);
  const [progress, setProgress] = useState(0);

  const handleStartHealing = () => {
    if (progress < 60) {
      navigate("/healing");
    } else if (progress < 90) {
      navigate("/stage2");
    }
  };

  return (
    <div className="min-h-screen bg-teal-50">
      <Navbar />
      <Routes>
        <Route path="/" element={<Healtogether />} />
        <Route
          path="/healing"
          element={
            <HomePage
              mentalHealth={mentalHealth}
              setMentalHealth={setMentalHealth}
              progress={progress}
              setProgress={setProgress}
            />
          }
        />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/chatbot" element={<Chatbot />} />
        <Route path="/game" element={<Game1 />} />
        <Route path="/Auth" element={<SwitchUi />} />
        <Route path="/mindTest" element={<MoodTest />} />
        <Route path="/Test" element={<MentalHealthTest />} />
        <Route
          path="/stage2"
          element={
            <HealingPage
              mentalHealth={mentalHealth}
              setMentalHealth={setMentalHealth}
              progress={progress}
              setProgress={setProgress}
            />
          }
        />
        <Route path="/community" element={<CommunityPage />} />
      </Routes>
    </div>
  );
}

export default App;
