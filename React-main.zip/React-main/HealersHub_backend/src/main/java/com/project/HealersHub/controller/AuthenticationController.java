package com.project.HealersHub.controller;


import com.project.HealersHub.dtos.*;
import com.project.HealersHub.entities.Role;
import com.project.HealersHub.entities.User;

import com.project.HealersHub.repository.RoleRepository;
import com.project.HealersHub.repository.UserRepository;
import com.project.HealersHub.security.JwtHelper;


import com.project.HealersHub.service.RefreshTokenService;
import com.project.HealersHub.service.UserService;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Set;

@RestController
@RequestMapping("/api/auth/public")
public class AuthenticationController {


    //method to generate token:

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtHelper jwtHelper;

    private final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ModelMapper modelMapper;

  //  @Value("${app.google.client_id}")
   // private String googleClientId;

  //  @Value("${app.google.default_password}")
   // private String googleProviderDefaultPassword;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserService userService;

    @Autowired
    private RefreshTokenService refreshTokenService;



 // SignUp or creating a new user
    @PostMapping("/signUp")
    public ResponseEntity<?> signUp(@Valid @RequestBody SignupRequest signUpRequest) {
        //        if (userRepository.existsByUserName(signUpRequest.getUsername())) {
//            return ResponseEntity.badRequest().body(new MessageResponse("Error: Username is already taken!"));
//        }
//
//        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
//            return ResponseEntity.badRequest().body(new MessageResponse("Error: Email is already in use!"));
//        }

        System.out.println("Pass ---------> " + signUpRequest.getPassword());
        UserDto userDto = new UserDto();
        userDto.setUserName(signUpRequest.getUsername());
        userDto.setEmail(signUpRequest.getEmail());
        userDto.setPassword(signUpRequest.getPassword());

        System.out.println("User pass -------> " + userDto.getPassword());

        UserDto userDto1 = userService.createUser(userDto);
        return new ResponseEntity<>(userDto1, HttpStatus.CREATED);
    }


    // Generating the new jwt token once the jwt token expires using the refresh token
    @PostMapping("/regenerate-token")
    public ResponseEntity<JwtResponse> regenerateToken(@RequestBody RefreshTokenRequest request) {

        RefreshTokenDto refreshTokenDto = refreshTokenService.findByToken(request.getRefreshToken());
        RefreshTokenDto refreshTokenDto1 = refreshTokenService.verifyRefreshToken(refreshTokenDto);
        UserDto user = refreshTokenService.getUser(refreshTokenDto1);
        String jwtToken = jwtHelper.generateToken(modelMapper.map(user, User.class));

        // apki choice refresh purana new bana lo
        JwtResponse response = JwtResponse.builder()
                .token(jwtToken)
                .refreshToken(refreshTokenDto)
                .user(user)
                .build();
        return ResponseEntity.ok(response);


    }

// Api to login the user
    @PostMapping("/signIn")
    public ResponseEntity<JwtResponse> login(@RequestBody JwtRequest request) {

        logger.info("Username {} ,  Password {}", request.getUsername(), request.getPassword());

        this.doAuthenticate(request.getUsername(), request.getPassword());

        User user = (User) userDetailsService.loadUserByUsername(request.getUsername());

        ///.. generate token...
        String token = jwtHelper.generateToken(user);
        //send karna hai response

        // Refresh Token

        RefreshTokenDto refreshToken = refreshTokenService.createRefreshToken(user.getEmail());

        System.out.println("Rolessss --------------> " + user.getRoles());


        JwtResponse jwtResponse = JwtResponse
                .builder()
                .token(token)
                .user(modelMapper.map(user, UserDto.class))
                .refreshToken(refreshToken)
                .build();
        return ResponseEntity.ok(jwtResponse);

    }

    // Authenticating the User and creating a authentication object.
    private void doAuthenticate(String email, String password) {
        try {
            Authentication authentication = new UsernamePasswordAuthenticationToken(email, password);
            authenticationManager.authenticate(authentication);

        } catch (BadCredentialsException ex) {
            throw new BadCredentialsException("Invalid Username and Password !!");
        }
    }

}


