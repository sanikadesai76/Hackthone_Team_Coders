import { useState, useEffect } from "react";
import axios from "axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import toast from "react-hot-toast";

const useAuth = () => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [refreshToken, setRefreshToken] = useState(
    localStorage.getItem("refreshToken") || ""
  );
  const navigate = useNavigate();

  useEffect(() => {
    const checkToken = async () => {
      if (token) {
        const decoded = jwtDecode(token);
        const currentTime = Date.now() / 1000;
        if (decoded.exp < currentTime) {
          await refreshAccessToken();
        } else {
          setUser(decoded);
        }
      }
    };
    checkToken();
  }, [token]);

  const login = async (username, password) => {
    try {
      const response = await api.post("/api/auth/public/signIn", {
        username,
        password,
      });
      console.log(response);
      const { token, user, refreshToken } = response.data;
      setToken(token);
      setRefreshToken(refreshToken.token);
      setUser(user);
      localStorage.setItem("user", user.userName);
      localStorage.setItem("token", token);
      localStorage.setItem("refreshToken", refreshToken.token);
      navigate("/healing");
    } catch (error) {
      console.error("Login error:", error);
      throw error;
    }
  };

  const signup = async (username, email, password) => {
    try {
      const response = await api.post("/api/auth/public/signUp", {
        username,
        email,
        password,
      });
      if (response.status === 201) {
        toast("SignUp Successfull");
        navigate("/healing");
      }
    } catch (error) {
      // Handle 400 errors with MessageResponse
      if (error.response && error.response.status === 400) {
        throw new Error(error.response.data.message);
      }
      console.error("Signup error:", error);
      throw new Error("Signup failed");
    }
  };

  const refreshAccessToken = async () => {
    try {
      const response = await axios.post("/api/auth/refresh", { refreshToken });
      const { token, user } = response.data;
      setToken(token);
      setUser(user);
      localStorage.setItem("token", token);
    } catch (error) {
      console.error("Refresh token error:", error);
      logout();
    }
  };

  const logout = () => {
    setToken("");
    setRefreshToken("");
    setUser(null);
    localStorage.removeItem("token");
    localStorage.removeItem("refreshToken");
    navigate("/");
  };

  return { user, token, login, signup, logout };
};

export default useAuth;
