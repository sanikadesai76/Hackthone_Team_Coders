import React, { useState } from "react";

const questions = [
  {
    text: "How often do you feel overwhelmed by your thoughts?",
    impact: [0, 1, 2, 3, 4, 5],
  },
  {
    text: "Do you find it difficult to enjoy activities that once made you happy?",
    impact: [0, 2, 4, 6, 8, 10],
  },
  {
    text: "How often do you experience sudden mood swings?",
    impact: [0, 2, 4, 6, 8, 10],
  },
  {
    text: "Do you struggle with excessive worrying or overthinking?",
    impact: [0, 2, 4, 6, 8, 10],
  },
  {
    text: "How frequently do you feel tired even after resting?",
    impact: [0, 2, 4, 6, 8, 10],
  },
  {
    text: "Do you feel disconnected from others, even in social situations?",
    impact: [0, 2, 4, 6, 8, 10],
  },
  {
    text: "Have you lost interest in personal hygiene or self-care?",
    impact: [0, 3, 6, 9, 12, 15],
  },
  {
    text: "Do you struggle with falling asleep or sleeping too much?",
    impact: [0, 3, 6, 9, 12, 15],
  },
  {
    text: "Do you often feel like you’re not good enough?",
    impact: [0, 3, 6, 9, 12, 15],
  },
  {
    text: "How often do you feel genuinely happy and at peace?",
    impact: [5, 4, 3, 2, 1, 0],
  },
];

const MentalHealthTest = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (index) => {
    setScore(score + questions[currentQuestion].impact[index]);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResult(true);
    }
  };

  const getFinalMessage = () => {
    if (score <= 15)
      return "🟢 Your mental health is in great condition. Stay positive!";
    if (score <= 40)
      return "🟡 You have some struggles. Consider relaxation techniques.";
    return "🔴 High stress detected. Don't hesitate to seek support.";
  };

  return (
    <div className="w-screen h-screen flex flex-col justify-center items-center bg-gradient-to-r from-yellow-400 to-orange-500 text-center p-6">
      <h1 className="text-4xl font-bold text-white mb-6 animate-bounce">
        🧠 Mental Health Test
      </h1>

      {!showResult ? (
        <div className="bg-white p-10 rounded-xl shadow-lg w-11/12 max-w-2xl animate-fadeIn">
          <p className="text-lg font-semibold text-gray-800 mb-4">
            {questions[currentQuestion].text}
          </p>
          <div className="flex justify-center flex-wrap gap-4">
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <button
                key={index}
                className="bg-green-600 text-white px-4 py-2 rounded-lg text-lg transition transform hover:bg-green-700 hover:scale-110"
                onClick={() => handleAnswer(index)}
              >
                {index}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-white p-10 rounded-xl shadow-lg w-11/12 max-w-2xl animate-fadeIn">
          <h2 className="text-xl font-bold text-gray-800">
            🎉 Test Completed!
          </h2>
          <p className="text-lg font-semibold text-gray-700 mt-4">
            Your Total Score: <strong>{score}/100</strong>
          </p>
          <p className="text-md text-gray-600 mt-2">{getFinalMessage()}</p>
        </div>
      )}
    </div>
  );
};

export default MentalHealthTest;
