import React from "react";

const CommunityPage = () => {
  const posts = [
    { user: "Alex", thought: "Finding peace through drawing.", canvas: true },
    { user: "Sam", thought: "Today feels lighter.", canvas: false },
  ];

  return (
    <div className="pt-16 p-6 max-w-7xl mx-auto">
      <h2 className="text-3xl font-bold text-teal-800 mb-6">Community Haven</h2>
      <div className="space-y-6">
        {posts.map((post, index) => (
          <div key={index} className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-teal-600">{post.user}</h3>
            <p className="text-teal-700 mt-2">{post.thought}</p>
            {post.canvas && <div className="mt-4 h-[200px]"></div>}
          </div>
        ))}
      </div>
      <div className="mt-6 text-center">
        <button className="bg-teal-600 text-white px-6 py-3 rounded-md hover:bg-teal-700">
          Share Your Thoughts
        </button>
      </div>
    </div>
  );
};

export default CommunityPage;
