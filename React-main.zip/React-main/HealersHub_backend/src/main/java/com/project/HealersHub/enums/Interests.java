package com.project.HealersHub.enums;

public enum Interests {
    Education, Programming;
}
