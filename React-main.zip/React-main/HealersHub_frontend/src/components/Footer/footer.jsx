import React from 'react';
import { Box, Typography, Link } from '@mui/material';

const Footer = () => {
  return (
    <Box id="contact" sx={{ bgcolor: '#3f51b5', color: '#fff', py: 6 }}>
      <Box sx={{ maxWidth: '1200px', mx: 'auto', px: 2, display: 'flex', flexWrap: 'wrap', gap: 4, justifyContent: 'space-between' }}>
        {/* Brand */}
        <Box sx={{ minWidth: 200 }}>
          <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
            HealersHub
          </Typography>
          <Typography variant="body2" sx={{ opacity: 0.8 }}>
            Empowering mental wellness with AI.
          </Typography>
        </Box>
        {/* Links */}
        <Box sx={{ minWidth: 200 }}>
          <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
            Quick Links
          </Typography>
          <Link href="#features" color="inherit" underline="hover" sx={{ display: 'block', mb: 1 }}>
            Features
          </Link>
          <Link href="#about" color="inherit" underline="hover" sx={{ display: 'block', mb: 1 }}>
            About
          </Link>
          <Link href="#contact" color="inherit" underline="hover" sx={{ display: 'block' }}>
            Contact
          </Link>
        </Box>
        {/* Contact */}
        <Box sx={{ minWidth: 200 }}>
          <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>
            Contact Us
          </Typography>
          <Typography variant="body2" sx={{ mb: 1 }}>
            Email: support@mindheal.com
          </Typography>
          <Typography variant="body2">
            Phone: +1 (123) 456-7890
          </Typography>
        </Box>
      </Box>
      <Typography variant="body2" align="center" sx={{ mt: 4, opacity: 0.7 }}>
        © 2025 MindHeal. All rights reserved.
      </Typography>
    </Box>
  );
};

export default Footer;