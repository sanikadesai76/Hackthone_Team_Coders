package com.project.HealersHub.enums;

public enum Providers {
        GOOGLE, FACEBOOK, GITHUB, SELF

}
