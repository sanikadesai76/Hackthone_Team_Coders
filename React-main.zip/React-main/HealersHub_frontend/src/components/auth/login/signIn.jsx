import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import useAuth from '../../../hooks/auth';

const Login = ({ toggle }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { login, user, logout } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      await login(username, password);
    } catch (err) {
      setError('Invalid credentials');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    setIsLoading(true);
    try {
      logout();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex w-full h-screen">
      <div className="w-1/2 flex flex-col justify-center items-center bg-white p-10 shadow-lg">
        <h2 className="text-2xl font-semibold text-gray-800">
          {user ? 'Welcome' : 'Welcome Back'}
        </h2>
        
        {user ? (
          <>
            <p className="text-gray-600 mb-4">Hello, {user.username}!</p>
            <button 
              onClick={handleLogout}
              disabled={isLoading}
              className={`w-full bg-gradient-to-b from-red-400 to-red-500 text-white text-2xl p-2 rounded ${
                isLoading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {isLoading ? 'Logging out...' : 'Log out'}
            </button>
          </>
        ) : (
          <>
            <p className="text-gray-600 mb-4">Please enter your details</p>
            {error && <p className="text-red-500 mb-3">{error}</p>}
            
            <form onSubmit={handleSubmit} className="w-full">
              <input 
                type="text" 
                placeholder="Username" 
                className="w-full p-2 border rounded mb-3" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                disabled={isLoading}
              />
              <input 
                type="password" 
                placeholder="Password" 
                className="w-full p-2 border rounded mb-3" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={isLoading}
              />
              <button 
                type="submit" 
                disabled={isLoading}
                className={`w-full bg-gradient-to-b from-yellow-400 to-orange-500 text-white text-2xl p-2 rounded ${
                  isLoading ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                {isLoading ? 'Logging in...' : 'Log in'}
              </button>
            </form>
            
            <p className="mt-3">
              Don't have an account? 
              <span 
                className="text-orange-500 cursor-pointer ml-1" 
                onClick={toggle}
              >
                Sign up
              </span>
            </p>
          </>
        )}
      </div>
      <div 
        className="w-1/2 h-screen bg-cover bg-center" 
        style={{ backgroundImage: "url('/auth_image.jpeg')" }}
      ></div>
    </div>
  );
};

export default Login;