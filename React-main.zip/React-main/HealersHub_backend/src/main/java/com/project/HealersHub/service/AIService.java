package com.project.HealersHub.service;

import com.project.HealersHub.dtos.LetterRequest;
import com.project.HealersHub.dtos.LetterResponseDto;

public interface AIService {

    LetterResponseDto generateLetter(LetterRequest letterRequest);
}
