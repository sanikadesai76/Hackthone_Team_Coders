package com.project.HealersHub.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.HealersHub.dtos.LetterRequest;
import com.project.HealersHub.dtos.LetterResponseDto;
import com.project.HealersHub.service.AIService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Map;

// import static com.fasterxml.classmate.AnnotationOverrides.builder;

@Service
public class AIServiceImpl implements AIService {

    private final WebClient webClient;

    @Value("${gemini.api.url}")
    private String geminiApiUrl;
    @Value("${gemini.api.key}")
    private String geminiApiKey;



    public AIServiceImpl(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }


@Override
    public LetterResponseDto generateLetter(LetterRequest letterRequest){
        String prompt = buildPrompt(letterRequest);

        System.out.println(geminiApiUrl + geminiApiKey);
        System.out.println(geminiApiKey);


        Map<String, Object> requestBody = Map.of(
                "contents", new Object[] {
                        Map.of("parts", new Object[] {
                                Map.of("text", prompt)
                        })
                }
        );

        try {
            String response = webClient.post()
                    .uri(geminiApiUrl + geminiApiKey)
                    .header("Content-Type", "application/json")
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            String aiResponse = extractResponseContent(response);

            LetterResponseDto letterResponseDto = LetterResponseDto
                    .builder()
                    .title("Have a nice day mate")
                    .content(aiResponse)
                    .build();

            return letterResponseDto;
        } catch (WebClientResponseException e) {

            System.err.println("API returned error: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
            LetterResponseDto letterResponseDto = LetterResponseDto
                    .builder()
                    .title("Have a nice day mate")
                    .content("We couldn’t fetch your letter right now, but know that you’re not alone.")
                    .build();
            return letterResponseDto;
        }
    }

    private String extractResponseContent(String response) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(response);
            return rootNode.path("candidates")
                    .get(0)
                    .path("content")
                    .path("parts")
                    .get(0)
                    .path("text")
                    .asText();

        }catch (Exception e){
            return "Error processing request: " + e.getMessage();
        }
    }

    private String buildPrompt(LetterRequest letterRequest) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate a deep self lifting letter with positive words reply for the User who is suffering with the mental health issues. It must help the user feel better based on the past circumstances and he's additional details are:").append(letterRequest.getUserName());
        if (letterRequest.getDepth() != null && !letterRequest.getDepth().isEmpty()){
            prompt.append("Use a ").append(letterRequest.getDepth()).append(" depth.");
        }
        return prompt.toString();
    }


}
