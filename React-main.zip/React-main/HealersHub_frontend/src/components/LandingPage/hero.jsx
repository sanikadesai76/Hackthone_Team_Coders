import React from 'react';

const Hero = ({ onStartHealing }) => {
  return (
    <section className="pt-24 pb-16 bg-gradient-to-r from-teal-500 to-blue-500 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-extrabold mb-4">
          Begin Your Mindful Journey
        </h2>
        <p className="text-lg md:text-xl mb-8">
          A sanctuary for healing with AI, mindfulness, and community support.
        </p>
        <button
          onClick={onStartHealing}
          className="bg-white text-teal-600 px-6 py-3 rounded-md font-semibold hover:bg-teal-100"
        >
          Start Healing Today
        </button>
      </div>
    </section>
  );
};

export default Hero;