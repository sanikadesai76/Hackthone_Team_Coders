import { useState } from 'react';
import Sidebar from './sidebar.jsx';
import Chatbot from './chatbot/chatbot.jsx';
import Stage2Healing from '../Stage2/stage2Home.jsx';

const UserHome = ({ auth }) => {
  const [mentalHealthStage, setMentalHealthStage] = useState(1);

  const detectMentalHealthStage = (messages) => {
    const anxiousWords = ['anxious', 'stressed', 'overwhelmed'];
    const messageText = messages.map(m => m.text.toLowerCase()).join(' ');
    const anxietyCount = anxiousWords.reduce((count, word) => 
      count + (messageText.includes(word) ? 1 : 0), 0);
    
    if (anxietyCount > 1) {
      setMentalHealthStage(2);
    }
  };

  return (
    <div className="user-home flex h-screen">
      <Sidebar />
      <main className="flex-1 p-6">
        {mentalHealthStage === 1 ? (
          <Chatbot onMessagesChange={detectMentalHealthStage} />
        ) : (
          <Stage2Healing axiosInstance={auth.axiosInstance} />
        )}
      </main>
    </div>
  );
};

export default UserHome;