import React, { useEffect, useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import useAuth from "../../../hooks/auth";

const HomePage = ({ progress, setProgress, userState }) => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const traumaMessages = [
    "Hey, just checking in. How are you feeling right now? 💙",
    "You are not alone. I’m here for you. Do you want to talk? 🫂",
    "It's okay to take a break. Have you taken a deep breath today? 🌿",
    "Remember, your feelings are valid. What’s on your mind? 🤍",
    "If things feel overwhelming, try to take it one step at a time. 💡",
    "You are doing better than you think. Do you need any support? 💜",
  ];

  useEffect(() => {
    toast.success("Welcome to your Healing Space!", {
      position: "bottom-right",
      duration: 5000,
    });

    let traumaCheckInterval;

    if (userState === "trauma") {
      traumaCheckInterval = setInterval(() => {
        const randomMessage =
          traumaMessages[Math.floor(Math.random() * traumaMessages.length)];
        toast((t) => (
          <div className="flex flex-col">
            <p className="text-lg">{randomMessage}</p>
            <button
              className="mt-2 bg-blue-500 text-white px-4 py-1 rounded-md"
              onClick={() => toast.dismiss(t.id)}
            >
              I'm Okay 😊
            </button>
          </div>
        ));
      }, 30 * 60 * 1000); // 30 minutes interval
    }

    return () => clearInterval(traumaCheckInterval); // Cleanup on unmount
  }, [userState]); // Re-run only if userState changes

  const updateProgress = (message) => {
    setProgress((prev) => Math.min(prev + 10, 100));
    toast.success(message, { position: "bottom-right" });
  };

  const openChatbot = () => {
    navigate("/chatbot");
    updateProgress("Great! Talking helps in healing. Keep going! 🎉");
  };

  const handleMindtest = () => {
    navigate("/Test");
    updateProgress("Self-assessment is key to growth! 💡");
  };

  const handleMindgames = () => {
    navigate("/game");
    updateProgress("Fun and relaxation help mental well-being! 🎮");
  };

  return (
    <div className="flex pt-34">
      <Toaster /> {/* Toast notifications container */}
      {/* Sidebar */}
      <div className="flex flex-col pl-4 w-1/4 bg-gradient-to-br from-yellow-400 to-orange-500 shadow-md pt-30 h-full">
        <h2 className="text-xl text-center font-bold text-indigo-600 mb-4">
          Dashboard
        </h2>
        <hr className="my-8 border-gray-200" />

        {/* Circular Progress Bar */}
        <div className="flex justify-center mb-6">
          <div className="relative w-24 h-24">
            <svg className="w-full h-full" viewBox="0 0 36 36">
              <path
                className="text-gray-200"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
              />
              <path
                className="text-indigo-600"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
                strokeDasharray={`${progress}, 100`}
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-lg font-bold">
              {progress}%
            </span>
          </div>
        </div>
        <hr className="my-8 border-gray-200" />

        {/* Quotes Section */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-center">Daily Quote</h3>
          <p className="text-gray-600 italic">
            "You are enough just as you are." - Meghan Markle
          </p>
        </div>
        <hr className="my-8 border-gray-200" />

        {/* Motivational Video */}
        <div className="pr-4">
          <h3 className="text-lg font-semibold text-center ">
            Motivational Video
          </h3>
          <iframe
            className="w-full h-60 mt-2"
            src="https://www.youtube.com/embed/1I9ADpXbD6c"
            title="Motivational Video"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div>
      {/* Main Content */}
      <div className="w-3/4 ml-5 pt-25">
        <h2 className="text-3xl font-bold text-gray-800 mb-6">
          Welcome to Your Healing Space
        </h2>
        <h2 className="text-3xl font-bold text-gray-800 mb-6">
          Hey {localStorage.getItem("user")}, Whats going on?
        </h2>

        {/* Chatbot Section */}
        <div className="bg-white p-4 rounded-lg shadow-md mb-6">
          <h3 className="text-xl font-semibold mb-2">AI Chatbot</h3>
          <p className="text-gray-600">
            Chat with our AI for real-time support.
          </p>
          <button
            onClick={openChatbot}
            className="mt-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
          >
            Start Chat
          </button>
        </div>

        {/* Mind Games & Test */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">Mind Games</h3>
            <p className="text-gray-600">Play to relax and gain insights.</p>
            <button
              onClick={handleMindgames}
              className="mt-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
            >
              Play Now
            </button>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">Mental Health Test</h3>
            <p className="text-gray-600">Assess your current state.</p>
            <button
              onClick={handleMindtest}
              className="mt-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
            >
              Take Test
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
