import React from "react";
import { Link } from "react-router-dom";

const NavBar = () => {
  return (
    <nav className="fixed h-20 top-0 left-0 w-full bg-black opacity-60  backdrop-blur-md shadow-lg py-4 px-8 flex justify-between items-center z-50">
      {/* Logo */}
      <div className="text-yellow-400 text-2xl font-bold uppercase tracking-wide drop-shadow-lg">
        EmoTrack
      </div>

      {/* Navigation Links */}
      <ul className="hidden  md:flex justify-between items-center  gap-6">
        <li>
          <Link
            to="/"
            className=" text-white text-2xl font-bold hover:text-yellow-400 transition duration-300"
          >
            Home
          </Link>
        </li>
        <li>
          <Link
            to="/about"
            className=" text-white text-2xl font-bold hover:text-yellow-400 transition duration-300"
          >
            About Us
          </Link>
        </li>
        <li>
          <Link
            to="/healing"
            className=" text-white text-2xl font-bold hover:text-yellow-400 transition duration-300"
          >
            Healing Space
          </Link>
        </li>
        {/* Login / Signup Button */}
        <li>
          <Link to="/Auth">
            <button className="relative flex items-center gap-2 px-6 py-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white pt-2 pb-2 font-semibold text-lg border-2 border-white-400 rounded-full transition-all duration-300 ease-in-out hover:scale-105 hover:border-white overflow-hidden group">
              <span className="relative z-10">Join Now</span>
              <svg
                className="w-5 h-5  transition-transform duration-300 group-hover:translate-x-1"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M9 5l7 7-7 7" />
              </svg>
              <span className="absolute inset-0 w-24 h-full bg-white opacity-10 transform -translate-x-32 group-hover:translate-x-32 transition-all duration-1000 ease-out"></span>
            </button>
          </Link>
        </li>
      </ul>
    </nav>
  );
};

export default NavBar;
