import React, { useState } from "react";
import LetterBox from "./LetterBox/letterBox";

const FeatureCard = ({ title, description, buttonText, onClick, imageSrc }) => (
  <div className="w-full bg-white border border-gray-300 shadow-md rounded-lg  overflow-hidden">
    <div className="relative w-full pt-[56.25%]">
      <img
        className="absolute top-0 left-0 w-full h-full object-cover"
        src={imageSrc || "https://via.placeholder.com/400x225"}
        alt={title}
        onError={(e) => {
          e.target.src = "https://via.placeholder.com/400x225";
        }}
      />
    </div>
    <div className="p-5">
      <h5 className="mb-2 text-2xl font-bold tracking-tight text-gray-90">
        {title}
      </h5>
      <p className="mb-3 font-normal text-gray-700">{description}</p>
      <button
        onClick={onClick}
        className="inline-flex  content-center items-center px-3 py-2 text-sm font-medium text-center text-white bg-gradient-to-r from-blue-500 to-purple-600 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
      >
        {buttonText}
        <svg
          className="rtl:rotate-180 w-3.5 h-3.5 ms-2"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 14 10"
        >
          <path
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M1 5h12m0 0L9 1m4 4L9 9"
          />
        </svg>
      </button>
    </div>
  </div>
);

const HealingPage = ({
  mentalHealth,
  setMentalHealth,
  progress,
  setProgress,
}) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showLetter, setShowLetter] = useState(false);
  const [canvasType, setCanvasType] = useState(null);

  const motivationalLetters = [
    "Dear You,\n\nYou are a beacon of light. Every step forward is a victory.",
    "Hey there,\n\nYour resilience inspires. Keep blooming!",
  ];

  const simulateProgress = () => {
    setMentalHealth((prev) => Math.min(prev + 10, 100));
    setProgress((prev) => Math.min(prev + 15, 100));
  };

  return (
    <div className="flex min-h-screen">
      <div
        className={`bg-gradient-to-b from-orange-400 to-yellow-500 shadow-md p-4 h-screen fixed transition-all duration-300 ${
          isSidebarOpen ? "w-1/4" : "w-16"
        }`}
      >
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="text-gray-800 mb-4 pt-16"
        >
          {isSidebarOpen ? "◄" : "►"}
        </button>
        {isSidebarOpen && (
          <>
            <h2 className="pt-8 pb-8 text-center text-[32px] font-bold text-gray-800 mb-4">
              Healing Dashboard
            </h2>
            <hr className="my-8 border-gray-200" />
            <div className="mb-6">
              <h3 className="text-[25px] text-center font-semibold text-gray-800">
                Mental Health
              </h3>
              <div className="relative pt-2 w-20 h-20 mx-auto">
                <svg className="w-full h-full" viewBox="0 0 36 36">
                  <path
                    className="text-yellow-200"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                  />
                  <path
                    className="text-orange-600"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeDasharray={`${mentalHealth}, 100`}
                  />
                  <span className="absolute inset-0 flex items-center justify-center text-lg font-bold text-gray-800">
                    {mentalHealth}%
                  </span>
                </svg>
              </div>
            </div>
            <hr className="my-8 border-gray-200" />
            <div className="pt-8 pb-8 mb-6">
              <h3 className="text-[25px] text-center font-semibold text-gray-800">
                Progress
              </h3>
              <div className="relative pt-2 w-20 h-20 mx-auto">
                <svg className="w-full h-full" viewBox="0 0 36 36">
                  <path
                    className="text-yellow-200"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                  />
                  <path
                    className="text-orange-600"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeDasharray={`${progress}, 100`}
                  />
                  <span className="absolute inset-0 flex items-center justify-center text-lg font-bold text-gray-800">
                    {progress}%
                  </span>
                </svg>
              </div>
            </div>
            <hr className="my-4 border-gray-200" />
            <div>
              <h3 className="text-lg font-semibold text-gray-800">
                Spiritual Insight
              </h3>
              <p className="text-gray-700 italic">
                "The soul always knows what to do to heal itself." - Caroline
                Myss
              </p>
            </div>
          </>
        )}
      </div>

      {/* Main Content with increased grid gap */}
      <div
        className={`p-8 pt-20 transition-all duration-300 ${
          isSidebarOpen ? "ml-[25%]" : "ml-16"
        } w-full bg-white`}
      >
        <h2 className="text-3xl font-bold text-gray-800 mb-8">
          Healing Sanctuary
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <FeatureCard
            title="Creative Canvas"
            description="Express yourself through drawing and storytelling"
            buttonText="Start Drawing"
            imageSrc="canvas.jpg"
            onClick={() => setCanvasType("normal")}
          />

          <FeatureCard
            title="AI Affirmative Letters"
            description="Receive personalized motivational messages"
            buttonText="Generate Letter"
            imageSrc="aiLetter.jpg"
            onClick={() => setShowLetter(true)}
          />

          <FeatureCard
            title="Talk to AI"
            description="Ask anything for guidance and support"
            buttonText="Start Talking"
            imageSrc="/images/ai-chat.jpg"
            onClick={simulateProgress}
          />

          <FeatureCard
            title="Meditation Zone"
            description="Join a guided meditation session"
            buttonText="Join Now"
            imageSrc="/images/meditation.jpg"
            onClick={() => {
              navigate("/mindTest");
            }}
          />
        </div>

        {showLetter && (
          <LetterBox
            content={
              motivationalLetters[
                Math.floor(Math.random() * motivationalLetters.length)
              ]
            }
            onClose={() => setShowLetter(false)}
          />
        )}
      </div>
    </div>
  );
};

export default HealingPage;
