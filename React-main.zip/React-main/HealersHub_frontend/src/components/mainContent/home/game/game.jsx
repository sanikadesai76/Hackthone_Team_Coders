import React, { useState, useEffect } from "react";

const negativeThoughts = [
  "I'm not good enough",
  "I always fail",
  "Nobody cares about me",
  "I can't do this",
  "I'm a disappointment",
];

const positiveAffirmations = [
  "I am worthy as I am",
  "Failure is a step to success",
  "I am loved and valued",
  "I can learn and grow",
  "I am doing my best",
];

const getRandomIndex = () => Math.floor(Math.random() * negativeThoughts.length);

const Game1 = () => {
  const [fallingBlocks, setFallingBlocks] = useState([]);
  const [score, setScore] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  const spawnBlocks = () => {
    const index1 = getRandomIndex();
    const index2 = getRandomIndex();
    const leftType = Math.random() < 0.5 ? "positive" : "negative";
    const rightType = leftType === "positive" ? "negative" : "positive";
    const leftText = leftType === "positive" ? positiveAffirmations[index1] : negativeThoughts[index1];
    const rightText = rightType === "positive" ? positiveAffirmations[index2] : negativeThoughts[index2];

    setFallingBlocks((prev) => [
      ...prev,
      { id: Date.now(), text: leftText, type: leftType, position: 0, lane: "left" },
      { id: Date.now() + 1, text: rightText, type: rightType, position: 0, lane: "right" },
    ]);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setFallingBlocks((prev) => prev.map((block) => ({ ...block, position: block.position + 10 })));
    }, 500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    setFallingBlocks((prev) => {
      return prev.filter((block) => {
        if (block.position >= 400) {
          if (block.type === "positive") {
            setMistakes((m) => m + 1);
            if (mistakes + 1 >= 3) setGameOver(true);
          }
          return false;
        }
        return true;
      });
    });
  }, [fallingBlocks]);

  const handleClick = (id, type) => {
    if (type === "positive") {
      setScore(score + 1);
    } else {
      setMistakes(mistakes + 1);
      if (mistakes + 1 >= 3) setGameOver(true);
    }
    setFallingBlocks((prev) => prev.filter((block) => block.id !== id));
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (!gameOver) spawnBlocks();
    }, 2000);
    return () => clearInterval(interval);
  }, [gameOver]);

  return (
    <div className="bg-gradient-to-br from-gray-900 to-gray-800 min-h-screen flex flex-col items-center">
      <h1 className="text-yellow-400 text-4xl font-extrabold mt-20">🧠 MindShift Game 🎮</h1>
      {gameOver ? (
        <div className="text-center text-white mt-12">
          <h2 className="text-red-500 text-3xl">Game Over! 💔</h2>
          <p className="text-lg">Your Score: {score}</p>
          <button className="mt-4 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700" onClick={() => window.location.reload()}>
            Restart
          </button>
        </div>
      ) : (
        <div className="bg-white bg-opacity-10 p-5 rounded-lg text-white mt-6 w-4/5 max-w-lg shadow-md">
          <p className="text-lg mb-2">Click the correct affirmation before it falls!</p>
          <p className="text-lg">Score: {score} | Mistakes: {mistakes}/3</p>
          <div className="relative w-full h-[400px] border-2 border-dashed border-white mt-4 overflow-hidden">
            {fallingBlocks.map((block) => (
              <div
                key={block.id}
                className={`absolute w-48 h-12 flex items-center justify-center rounded-md font-bold text-white cursor-pointer shadow-lg transition-all duration-500 ${
                  block.type === "positive" ? "bg-green-500" : "bg-red-500"
                } ${block.lane === "left" ? "left-1/4 -translate-x-1/2" : "left-3/4 -translate-x-1/2"}`}
                onClick={() => handleClick(block.id, block.type)}
                style={{ top: `${block.position}px` }}
              >
                {block.text}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Game1;
