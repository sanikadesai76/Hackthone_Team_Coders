import React from "react";

const AboutUs = () => {
  return (
    <div className="flex flex-col md:flex-row w-full h-screen overflow-hidden rounded-lg">
      {/* Left Side: Text Content */}
      <div className="flex flex-col justify-center items-center md:items-start md:w-1/2 bg-gradient-to-br from-gray-200 to-gray-300 p-10 rounded-lg">
        <h2 className="text-2xl md:text-3xl font-bold text-blue-900 text-center md:text-left">
          About HealTogether
        </h2>
        <p className="text-lg font-medium text-blue-900 text-center md:text-left mt-4">
          Life can be overwhelming, and We’ve been there too, struggling with
          stress and searching for peace. But through spirituality, I found a
          way to heal, reconnect with myself, and grow stronger. HealTogether is
          my way of sharing that journey with you. This platform is a space
          where we explore ways to overcome stress, find inner peace, and heal
          through spirituality. You're not alone, we heal together!
        </p>

        {/* Explore Button */}
        <a href="/auth" className="mt-6">
          <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg text-lg font-semibold transition-transform transform hover:scale-105">
            Explore
          </button>
        </a>
      </div>

      {/* Right Side: Image */}
      <div className="md:w-1/2 h-64 md:h-full bg-cover bg-center" style={{ backgroundImage: "url('/about_image.jpg')" }}></div>
    </div>
  );
};

export default AboutUs;